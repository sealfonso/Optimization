function C=submatriz(A,j1,j2,j3)
C=[A(:,j1) A(:,j2) A(:,j3)];
end
