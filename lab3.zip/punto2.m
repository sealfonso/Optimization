function R=punto2(A,b,y)
R={}
j=0;
for i=1:length(y)
Q=submatriz(A,y(i,1),y(i,2),y(i,3))
if rank(Q)==length(Q)
    j=j+1
    x=inv(Q)*b;
    R(j,:)={x,Q}
end
end
end

    
    